#ifndef __ASM_BITSPERLONG_H
#define __ASM_BITSPERLONG_H

#define __BITS_PER_LONG 64

#endif	/* __ASM_BITSPERLONG_H */
