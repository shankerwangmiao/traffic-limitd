#ifndef _LINUX_POSIX_TYPES_H
# define _LINUX_POSIX_TYPES_H

# include <linux/stddef.h>

#endif /* _LINUX_POSIX_TYPES_H */
